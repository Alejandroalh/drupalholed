The code for this module is in 6.x-1.x and 7.x-1.x branches as is the
standard on Drupal.org.

The vulnerable.module which accompanies the book http://crackingdrupal.com

This module is for educational purposes only. "Fixes" welcome
as pull requests on github.

Send praise via tweets [@greggles](https://twitter.com/greggles) or blog posts that link to 
[Cracking Drupal](http://crackingdrupal.com/).

Send complaints via issue reports on github :)

Thanks for trying it out!